<?php
// Consignment Stock Debugging Page

// Add debug page to admin menu for testing
function add_consignment_stock_debug_menu() {
    add_submenu_page(
        'consignment-stock',
        'Debug Consignment Stock', 
        'Debug', 
        'manage_options', 
        'consignment-stock-debug', 
        'consignment_stock_debug_page'
    );
}
add_action('admin_menu', 'add_consignment_stock_debug_menu');

// Debug page content
function consignment_stock_debug_page() {
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }
    
    global $wpdb;
    $consignment_table = $wpdb->prefix . 'consignment_stock';
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$consignment_table'") === $consignment_table;
    
    // Handle create table action
    if (isset($_POST['create_table']) && check_admin_referer('consignment_debug_action')) {
        create_consignment_stock_table();
        echo '<div class="notice notice-success is-dismissible"><p>Table creation attempted. Refresh to check if it exists now.</p></div>';
    }
    
    // Handle add test data action
    if (isset($_POST['add_test_data']) && check_admin_referer('consignment_debug_action')) {
        if (!$table_exists) {
            echo '<div class="notice notice-error is-dismissible"><p>Table does not exist. Please create it first.</p></div>';
        } else {
            // Add some test data
            $test_users = get_users(array('role__in' => array('customer', 'subscriber'), 'number' => 2));
            
            if (!empty($test_users)) {
                $products = array(
                    array('id' => 'TEST001', 'name' => 'Test Product 1'),
                    array('id' => 'TEST002', 'name' => 'Test Product 2'),
                    array('id' => 'TEST003', 'name' => 'Test Product 3')
                );
                
                foreach ($test_users as $user) {
                    foreach ($products as $product) {
                        $wpdb->replace(
                            $consignment_table,
                            array(
                                'user_id' => $user->ID,
                                'product_id' => $product['id'],
                                'product_name' => $product['name'],
                                'stock_quantity' => rand(5, 50),
                                'last_updated' => current_time('mysql')
                            ),
                            array('%d', '%s', '%s', '%d', '%s')
                        );
                    }
                }
                
                echo '<div class="notice notice-success is-dismissible"><p>Test data added for ' . count($test_users) . ' users.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>No customers found to add test data.</p></div>';
            }
        }
    }
    
    // Handle drop table action
    if (isset($_POST['drop_table']) && check_admin_referer('consignment_debug_action')) {
        drop_consignment_stock_table();
        echo '<div class="notice notice-success is-dismissible"><p>Table drop attempted. Refresh to check if it was removed.</p></div>';
    }
    
    ?>
    <div class="wrap">
        <h1>Consignment Stock Debug</h1>
        
        <div class="debug-section" style="background: #fff; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h2>Table Status</h2>
            
            <?php if ($table_exists) : ?>
                <div class="notice notice-success" style="margin-left: 0;"><p>✅ Consignment Stock table exists: <code><?php echo $consignment_table; ?></code></p></div>
                
                <?php 
                // Get table structure
                $table_structure = $wpdb->get_results("DESCRIBE $consignment_table");
                if (!empty($table_structure)) : 
                ?>
                    <h3>Table Structure</h3>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>Field</th>
                                <th>Type</th>
                                <th>Null</th>
                                <th>Key</th>
                                <th>Default</th>
                                <th>Extra</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($table_structure as $column) : ?>
                                <tr>
                                    <td><?php echo $column->Field; ?></td>
                                    <td><?php echo $column->Type; ?></td>
                                    <td><?php echo $column->Null; ?></td>
                                    <td><?php echo $column->Key; ?></td>
                                    <td><?php echo $column->Default; ?></td>
                                    <td><?php echo $column->Extra; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                
                <?php 
                // Get record count
                $record_count = $wpdb->get_var("SELECT COUNT(*) FROM $consignment_table");
                ?>
                <h3>Records</h3>
                <p>Total records: <strong><?php echo $record_count; ?></strong></p>
                
                <?php if ($record_count > 0) : ?>
                    <h3>Sample Data (10 records)</h3>
                    <?php 
                    $sample_data = $wpdb->get_results("SELECT cs.*, u.display_name 
                                                    FROM $consignment_table cs
                                                    LEFT JOIN {$wpdb->users} u ON cs.user_id = u.ID
                                                    LIMIT 10");
                    ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Stock</th>
                                <th>Last Updated</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sample_data as $item) : ?>
                                <tr>
                                    <td><?php echo $item->id; ?></td>
                                    <td><?php echo $item->display_name; ?> (ID: <?php echo $item->user_id; ?>)</td>
                                    <td><?php echo $item->product_id; ?></td>
                                    <td><?php echo $item->product_name; ?></td>
                                    <td><?php echo $item->stock_quantity; ?></td>
                                    <td><?php echo $item->last_updated; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                
            <?php else : ?>
                <div class="notice notice-error" style="margin-left: 0;"><p>❌ Consignment Stock table does not exist.</p></div>
            <?php endif; ?>
        </div>
        
        <div class="debug-actions" style="background: #fff; padding: 20px; border-radius: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h2>Debug Actions</h2>
            
            <form method="post" action="" style="margin-bottom: 15px;">
                <?php wp_nonce_field('consignment_debug_action'); ?>
                <input type="submit" name="create_table" class="button button-primary" value="Create/Update Table">
                <?php if ($table_exists) : ?>
                    <input type="submit" name="add_test_data" class="button" value="Add Test Data">
                    <input type="submit" name="drop_table" class="button button-secondary" value="Drop Table" onclick="return confirm('Are you sure you want to drop the table?');">
                <?php endif; ?>
            </form>
            
            <p>Click "Create/Update Table" to ensure the table exists with the correct structure.</p>
            <?php if ($table_exists) : ?>
                <p>"Add Test Data" will add sample stock items for the first two customers found.</p>
                <p>"Drop Table" will completely remove the table and all its data.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}