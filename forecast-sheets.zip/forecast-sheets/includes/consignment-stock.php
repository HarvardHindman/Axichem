<?php
// Frontend Consignment Stock Tab

// Add Consignment Stock tab to My Account page
function add_consignment_stock_tab($items)
{
    $items['consignment-stock'] = 'Consignment Stock';
    return $items;
}
add_filter('woocommerce_account_menu_items', 'add_consignment_stock_tab', 10, 1);

// Reorder account menu to put Consignment Stock tab after Forecast Sheets and before Orders
function reorder_consignment_stock_tab($items)
{
    // If forecast-sheet doesn't exist, keep the original order
    if (!isset($items['forecast-sheet'])) {
        return $items;
    }
    
    // Create a new ordered array with our tab in the right position
    $new_items = array();
    
    foreach ($items as $key => $label) {
        $new_items[$key] = $label;
        
        // After forecast-sheet tab, add our consignment stock tab
        if ($key === 'forecast-sheet') {
            // Remove to avoid duplication if it already exists elsewhere
            if (isset($items['consignment-stock'])) {
                unset($items['consignment-stock']);
            }
            $new_items['consignment-stock'] = 'Consignment Stock';
        }
    }
    
    return $new_items;
}
// Use priority 20 to ensure this runs after the forecast-sheets plugin's reordering (at 10)
// but before the axichem-orders reordering (at 30)
add_filter('woocommerce_account_menu_items', 'reorder_consignment_stock_tab', 20);

// Define Consignment Stock endpoint
function consignment_stock_endpoint()
{
    add_rewrite_endpoint('consignment-stock', EP_ROOT | EP_PAGES);
    
    // Flush rewrite rules on the first run
    if (get_option('consignment_stock_flush_rewrite_rules', false) === false) {
        flush_rewrite_rules();
        update_option('consignment_stock_flush_rewrite_rules', true);
    }
}
add_action('init', 'consignment_stock_endpoint');

// Content for the Consignment Stock tab
function consignment_stock_tab_content()
{
    // Get current user ID
    $user_id = get_current_user_id();
    
    // Query consignment stock from database
    global $wpdb;
    $consignment_table = $wpdb->prefix . 'consignment_stock';
    
    $consignment_items = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $consignment_table WHERE user_id = %d ORDER BY product_name ASC",
            $user_id
        )
    );
    
    // Display consignment stock
    ?>
    <div class="forecast_header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; background-color: #f9fbff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
        <h3 style="margin: 0; font-size: 24px; color: #333; font-weight: 600;">My Consignment Stock</h3>
    </div>
    
    <div class="forecast_body axichem-form">
        <?php if (empty($consignment_items)) : ?>
            <p>You don't have any consignment stock assigned to your account yet. Please contact Axichem for more information.</p>
        <?php else : ?>
            <table id="consignment-stock-table" class="display responsive" style="width:100%">
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Available Stock</th>
                        <th>Last Updated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($consignment_items as $item) : ?>
                        <tr>
                            <td><?php echo esc_html($item->product_id); ?></td>
                            <td><?php echo esc_html($item->product_name); ?></td>
                            <td><?php echo esc_html($item->stock_quantity); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($item->last_updated)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <script>
                jQuery(document).ready(function($) {
                    if ($('#consignment-stock-table').length) {
                        $('#consignment-stock-table').DataTable({
                            responsive: true,
                            order: [[1, 'asc']],
                            language: {
                                search: "Search stock:",
                                lengthMenu: "Show _MENU_ products",
                                info: "Showing _START_ to _END_ of _TOTAL_ products",
                                infoEmpty: "No products available",
                                infoFiltered: "(filtered from _MAX_ total products)"
                            },
                            dom: '<"top"lf>rt<"bottom"ip><"clear">',
                            lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]]
                        });
                    }
                });
            </script>
        <?php endif; ?>
    </div>
    <?php
}
add_action('woocommerce_account_consignment-stock_endpoint', 'consignment_stock_tab_content');